/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//char siz=256//

#include <stdio.h>
#include<string.h>
#include<stdbool.h>
bool anagram(char s1[],char s2[]){
    int c[256]={0};
    int i;
    if(strlen(s1)!=strlen(s2)){
        return false;
    }
    for(i=0;s1[i] && s2[i];i++){
        c[(int)s1[i]]++;
        c[(int)s2[i]]--;
    }
    for(i=0;i<256;i++){
        if(c[i]!=0){
            return false;
        }
    }
    return true;
}
int main()
{
    char s1[100],s2[100];
    printf("enter the first string:");
    scanf("%s",s1);
    printf("enter the second string:");
    scanf("%s",s2);
    if(anagram(s1,s2)){
        printf("Both strings are anagram\n");
    }
    else{
        printf("Both strings are not anagram\n");
    }
    return 0;
}
